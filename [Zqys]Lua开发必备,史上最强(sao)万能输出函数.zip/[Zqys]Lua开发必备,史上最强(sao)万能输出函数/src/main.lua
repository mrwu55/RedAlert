require 'print' -- print会加载为全局变量
------------------

print('123')
print(123)
print(false)

print{123}


local tab = {1, 2, test = 'aaa', 3, {'fuck', function() end, {false, true}}}

print(tab) -- 打印table

print(tab, 1, false, '流弊', function() end) -- 打印多参数 

-- print(_G)之前，先开启 (附加功能: 替换table中string的转义) ，不然可能会引起不必要的换行
--print(_G) 

