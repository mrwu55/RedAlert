-- [[ print functions start ]]
local _SpaceNum = {[0] = ''}
for i = 1, 10 do
    _SpaceNum[i] = ('\t'):rep(i)
end
local prt = print
function print(...)
    local arg, str, _print = {...}, {}
    --[[ (附加功能: 显示输出文件&行号)
    local deb = debug.getinfo(2)
    str[1] = deb.short_src .. ':' .. deb.currentline .. ': ' --]]
    if #arg == 1 then
        if type(arg[1]) ~= 'table' then
            str[#str + 1] = tostring(arg[1])
            str = table.concat(str)
        else
            _print = function(t, SpaceNum)
                SpaceNum = SpaceNum + 1
                for k, v in pairs(t) do
                    local value, _type = tostring(v), type(v)
                    --[[ (附加功能: 显示key的类型)
                    local typek = type(k) == 'number' and 'n' or 's' --]]
                    if _type == 'table' and k ~= '_G' and not v.package then
                        str[#str + 1] =
                            (_SpaceNum[SpaceNum] or ('\t'):rep(SpaceNum)) ..
                            (typek or '') .. '[' .. tostring(k) .. '](table) = {\r'
                        --[ (附加功能: 更加人性化的空table)
                        if not next(v) then
                            str[#str] = str[#str]:gsub('\r', '}\r')
                        else -- ]]
                            _print(v, SpaceNum)
                            str[#str + 1] = (_SpaceNum[SpaceNum] or ('\t'):rep(SpaceNum)) .. '}\r'
                        end
                    else
                        --[ (附加功能: 更加人性化的function显示)
                        value = _type == 'function' and value:gsub('[^0]+', '', 1) or value --]]

                        --[ (附加功能: 更加简便的前缀)
                        _type = _type:sub(1, not (#_type > 6) and 3 or 4) --]]

                        --[[ (附加功能: 替换table中string的转义)
                        for k, v in pairs {['r'] = '\r', ['t'] = '\t', ['n'] = '\n', ['0'] = '\0'} do
                            value = value:gsub(v, '(◇\\' .. k .. ')') --注意, 1.9中使用必须把↑↑上面的['0']项删掉
                        end --]]
                        str[#str + 1] =
                            (_SpaceNum[SpaceNum] or ('\t'):rep(SpaceNum)) ..
                            (typek or '') .. '[' .. tostring(k) .. '](' .. _type .. ') = ' .. value .. '\r'
                    end
                end
            end
            str[#str + 1] = '\r\r◇ Table = {\r'
            _print(arg[1], 0)
            str[#str + 1] = '}\r\r'
            str = table.concat(str)
        end
    else
        for i = 1, #arg do
            local _type = type(arg[i])
            str[#str + 1] =
                ((_type == 'table' or _type == 'function') and '◇' .. _type:gsub( '.', function(a) return a:upper() end, 1) or
                tostring(arg[i])) .. (i ~= #arg and ', ' or '')
        end
        str = table.concat(str)
    end
    prt(str)
end
-- [[ print functions end ]]



