require "utilcaiji"
require "UiShow"
local bb = require("badboy")
local isFirstComming = true
screen.init(screen.PORTRAIT)
local iscaijiLoop = true
local monsterGrade = 14

function 循环打野()
	sysLog("又进来了")
	local freeNum = freeTest(5)
	if getfight()==true or freeNum==0 then
		sysLog("任务正在进行，取消")
		return
	end
	sysLog("开始")
	local notChange = true
	local run = true
	while run do
		local num = freeTest(5)
		if num ~=0 then
			run =  findMonster(monsterGrade,true)
			--			if notChange then--切换野怪类型
			--								sysLog("切换野怪类型")
			--								monsterGrade =12
			--								if findMonster(monsterGrade,true)==false  then
			--									break
			--								end
			--								notChange = false
			--							else
			--				break
			--			end
			
		end
		local i =0
		sysLog("休息三分钟")
		while run do
			--searchWithGrade(8,2,false,4)
			local num = freeTest(5)
			sysLog("空闲队列数："..num)
			if num ~=0 then
				run = findMonster(monsterGrade,true)
				
			end
			i= i+1
			comBackOrTt()
			if i>=36 then
				break
			end
			sleep(5000)
		end
		
	end
	sysLog(getfight())
	
end
function restTestingFucked()
	testingErrorTips();
	testTtisUserd();
	
	go()
	
	local i =0
	while true  do
		i= i+1
		comBackOrTt()
		if i>=300 then
			break
		end
		sleep(1000)
	end
	
end

function start()
	--	showTips()
	testTtisUserd();
	while true do
		comBackOrTt()
		local freeNum = freeTest(5)
		if freeNum~=0 then
			searchWithGrade(8,1,false,5)
			
			--			sysLog("打野")
			--back()
			--			sleep(5000)
			--			循环打野()
		end
		
		sysLog("睡觉30分钟")
		restTestingFucked()
		
	end
	
end




function initUi()
	bb.loaduilib()
	local json = bb.getJSON()
	local rootview = RootView:create({style = ViewStyle.CUSTOME})
	local page = Page:create("page")
	page.text ="采集打野设置"
	
	local label = Label:create("label", {color = "255, 255, 0"})
	label.text = "采集打野"
	page:addView(label)
	local edit = Edit:create("edit", {prompt = "选择队列数"})
	edit.align = TextAlign.LEFT
	page:addView(edit)
	
	local checkboxgroup = CheckBoxGroup:create('checkboxgroup')
	checkboxgroup:setList('打叛军')
	checkboxgroup:setSelects(0)
	page:addView(checkboxgroup)
	
	rootview:addView(page)
	
	
	uijson = json.encode(rootview)
	showUI(uijson)
	
end
function initWui()
	bb.loaduilib()
	local wui = require('wui.wui')
	local page = Page:create("page")
	-- createLayout本质上只是构建了UI组件的table描述
	local layout1 = wui.Checkbox.createLayout({ title = '选项1', value = 1, hasTopBorder = true, hasBottomBorder = false })
	local layout2 = wui.Checkbox.createLayout({ title = '选项2', value = 2, checked = true, config = { checkedColor = '#f00', uncheckedColor = '#0f0' } })
	local layout3 = wui.TabPage.createLayout({pages=page,config = { currentPage = 0, tabTitles = {},pageWidth =600,pageHeight =650 }})
	
	local rootLayout = {
		view = 'scroller',
		subviews = {
			
			--        layout1,
			--        layout2,
			layout3
		}
	}
	local context = UI.createContext(rootLayout)
	context:show()
	while true do
		sleep(1000)
	end
	
end

start()
--initUi()
--initWui()
--showMyUi()
--showTips()

