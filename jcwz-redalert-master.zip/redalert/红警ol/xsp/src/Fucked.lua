
require "MonsterUtil"

local hasTt = false
local isFire = false

local pointList = {Point(630,348),Point(625,505),Point(629,659),Point(625,813),Point(622,965)}
function comBackOrTt()
	sleep(800);
	if hasTt ==false then
		points = screen.findColors(Rect(10, 626, 142, 70),
			"0|0|0x9a1b15,41|2|0x9a1a15,80|-13|0x861b1a,119|9|0xa71815",
			95, screen.PRIORITY_DEFAULT)
		if #points ~= 0 then --燃火被攻击
			sysLog("燃火被攻击")
			back();
			go();
			sleep(1000);
			click(369,586)--点击屏幕中央
			sleep(1000);
			openTt();
		end
	end
	if isFire then
		sysLog("燃火转换监测点")
		fuckPoint = screen.findColors(Rect(10, 626, 142, 70),
			"0|0|0x9a1b15,41|2|0x9a1a15,80|-13|0x861b1a,119|9|0xa71815",
			95, screen.PRIORITY_DEFAULT);
	else
			fuckPoint = screen.findColors(Rect(17, 639, 56, 50),
			"0|0|0x921919,42|2|0x951a15",
			95, screen.PRIORITY_DEFAULT);
	end
	
	sysLog("循环被攻击检测")
	sleep(800);
	if #fuckPoint ~= 0 then --被攻击或被侦查
		click(43,667)--点击红灯
		sleep(1000)
		newFuckedTest()
	end
	
end
function testFightNum()
	
	point = findColors({558, 942, 695, 989},
		"0|0|0x39629b,97|0|0x3b649f",
		95, 0, 0, 0)
	if #point ~= 0 then
		return 5;
	end
	
	point = findColors({560, 787, 696, 834},
		"0|0|0x3e6eab,90|-1|0x3d6ba8",
		95, 0, 0, 0)
	if #point ~= 0 then
		return 4;
	end
	point = findColors({560, 787, 696, 834},
		"0|0|0x3e6eab,90|-1|0x3d6ba8",
		95, 0, 0, 0)
	if #point ~= 0 then
		return 4;
	end
	point = findColors({561, 632, 696, 683},
		"0|0|0x3e6fac,92|-1|0x3d6ca9",
		95, 0, 0, 0)
	if #point ~= 0 then
		return 3;
	end
	point = findColors({560, 481, 694, 526},
		"0|0|0x375d94,91|2|0x3b649e",
		95, 0, 0, 0)
	if #point ~= 0 then
		return 2;
		
	end
	point = findColors({563, 322, 695, 372},
		"0|0|0x4073b2,88|-2|0x3e6eab",
		95, 0, 0, 0)
	if #point ~= 0 then
		return 1;
	else
		return 0;
	end
end


function newFuckedTest()
	
	points = screen.findColors(Rect(254, 964, 210, 56),
		"0|0|0xbb7e31,127|0|0xbc7e31,60|-1|0xbb7d30",
		95, screen.PRIORITY_DEFAULT)
	if #points ~= 0 then
		sysLog("围墙界面，燃火状态")

		isFire = true;
		if hasTt == false then
			back();
			go();
			sleep(1000);
			click(369,586)--点击屏幕中央
			sleep(1000);
			openTt();
		end
		return
	end
	
	
	
	point = findColors({633, 240, 683, 293},
		"0|0|0x470c0c,38|1|0x4b0d0d,20|20|0x891d1d",
		95, 0, 0, 0)
	if #point ~= 0 then
		sysLog("战区司令部")
		click(660,270)--点击屏幕中央
		return;
	end
	local loopNum = 0;
	while true do
		sysLog("攻击队列检测循环")
		sleep(1000);
		local resultNum = testFightNum()
		sysLog("总共攻击队列-->"..resultNum);
		if resultNum == 0 then
			go();
			break
		end
		if resultNum == 1 then
			loopFuckedTt(1);
			go();
			break;
		elseif resultNum>2 then--预防破脚本
			if hasTt ==false then
				sleep(1000);
				sysLog("慌得一批，开罩为敬");
				back();
				go();
				sleep(1000);
				click(369,586)--点击屏幕中央
				sleep(1000);
				openTt();
				break;
			else
				sysLog("五个队列循环")
				loopNum = loopNum+1;
				if loopNum>resultNum then
					sysLog("全部情况处理完毕退出循环");
					go();
					break
				end
				loopFuckedTt(loopNum)
			end
			
		else--2个攻击队列
			sysLog("2到4个队列循环流程")
			loopNum = loopNum+1;
			if loopNum>resultNum then
				sysLog("全部情况处理完毕退出循环");
				go();
				break
			end
			loopFuckedTt(loopNum);
		end
	end
	
end

---多个队列时流程
function loopFuckedTt(loop)
	sysLog("多个队列撤退开罩流程"..loop);
	local resultIsfuck = testFuckedOrzc(pointList[loop]);
	if resultIsfuck then--被攻击
		sleep(1000)
		click(186,458)--点击被攻击坐标
		sleep(1000)
		click(369,586)--点击屏幕中央
		sleep(1000)
		points = findColors({169, 550, 213, 602},
			"0|0|0xf9e9ac,0|13|0xe7cd87,-17|8|0x150d0d,11|7|0x150d0d",
			95, 0, 0, 0)
		if #points==0 then--基地被攻击
			if hasTt ==false then
				openTt()
			else
				sysLog("有罩子")
				go();
				click(43,667)--点击红灯
			end
			
		else--资源点被攻击
			sysLog("资源点被攻击")
			sleep(1000)
			click(526,590)--召回
			go();
			click(43,667)--点击红灯
		end
		
		
	else--被侦查
		sysLog("被侦查-->点击忽略"..loop);
		click(355,835);
		
	end
end

--检测被攻击或者被侦查
function testFuckedOrzc(pos)
	clickPonit(pos)--点击查看
	sleep(1000)
	points = screen.findColors(Rect(256, 811, 210, 53),
		"0|0|0x3c659c,57|0|0x3c659e,110|1|0x3c67a0",
		95, screen.PRIORITY_DEFAULT)
	if #points~=0 then--侦查
		
		return false;
	else
		return true;
		
	end--查看界面检测
end

function openTt()
	sleep(500)
	click(530,592)--点击基地增益
	sleep(1000)
	sysLog("点击时空屏障栏")
	click(455,229)--点击罩子
	sleep(1000)
	sysLog("点击开罩")
	click(576,398)--点击开罩
	sleep(1000)
	point = findColors({408, 697, 602, 750},
		"0|0|0x3f70ac,58|-4|0x3c67a0,114|-5|0x3b649c",
		95, 0, 0, 0)
	if #point ~= 0 then
		sysLog("金币开罩")
		click(504,719);
	end
	hasTt = true
	go();
	click(43,667)--点击红灯
end


function  testIsFindBug()
	
	point = findColors({558, 319, 701, 530},
		"0|0|0x3c69a4,46|0|0x3f6ca9,91|1|0x466da9,-3|152|0x39619a,47|152|0x3e659f,85|152|0x46649d",
		95, 0, 0, 0)
	if #point ~= 0 then
		sysLog("至少两个侦查或攻击");
		back();
		go();
		click(369,586)--点击屏幕中央
		sleep(1000);
		click(530,592)--点击基地增益
		sleep(1000)
		sysLog("点击时空屏障栏")
		click(455,229)--点击罩子
		sleep(1000)
		
		sysLog("开罩了 点击576,398")
		
		click(576,398)--点击开罩
		sleep(1000);
		point = findColors({408, 697, 602, 750},
			"0|0|0x3f70ac,58|-4|0x3c67a0,114|-5|0x3b649c",
			95, 0, 0, 0)
		if #point ~= 0 then
			sysLog("金币开罩")
			click(504,719);
		end
		return true;
	end
	return false;
end
function click(x,y)
	local poss = Point(x,y)
	touch.down(1, poss)
	sleep(15)
	touch.up(1, poss)
end
function clickPonit(poss)
	touch.down(1, poss)
	sleep(15)
	touch.up(1, poss)
end

function testTtisUserd()
	back();
	click(43,667)--点击红灯
	sleep(1000)
	points = screen.findColors(Rect(254, 964, 210, 56),
		"0|0|0xbb7e31,127|0|0xbc7e31,60|-1|0xbb7d30",
		95, screen.PRIORITY_DEFAULT)
	if #points ~= 0 then
		sysLog("着火啦")
		isFire = true
	else
		sysLog("没着火")
		isFire = false
	end
	sysLog("检测是否开罩")
	go();
	sleep(1000);
	click(369,586)--点击屏幕中央
	sleep(1000);
	click(530,592)--点击基地增益
	sleep(1000);
	points = screen.findColors(Rect(192, 252, 35, 24),
		"0|0|0x387abd,9|0|0x387abd",
		95, screen.PRIORITY_DEFAULT)
	if #points == 0 then
		sysLog("罩子检测--没有罩子")
		hasTt = false;
		
	else
		sysLog("罩子检测--有罩子")
		hasTt = true;
	end
	click(54,91);
end