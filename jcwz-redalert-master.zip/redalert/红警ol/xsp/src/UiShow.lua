
local tvTips
local context
function showMyUi()
local rootLayout = {
    view = 'scroller',
    style = {
        width = 750,
        ['background-color'] = '#00000000',
        ['align-items'] = 'center'
    },
    subviews = {
        {
            id = 'test_btn',
            view = 'div',
            class = 'btn',
            subviews = {
                {
                    view = 'text',
                    class = 'txt',
                    value = 'ok'
                }
            }
        }
    }
}
local globalStyle = {
    txt = {
        color = '#41b883',
        ['font-size'] = 40,
        ['padding-top'] = 10,
        ['padding-bottom'] = 10
    },
    logo = {
        width = 200,
        height = 30,
        padding = 10,
        margin = 20
    },
    btn = {
        width = 500,
        height = 80,
		margin = 20,
        ['align-items'] = 'center',
        ['border-width'] = 1.5,
        ['border-radius'] = 24,
        ['border-color'] = '#dddddd',
        ['background-image'] = 'linear-gradient(to top, #E3F5FB, #F9FEFF)'
    },
    ['btn:active'] = {
        ['background-image'] = 'linear-gradient(to top, #DFDFDF, #AFAFAF)'
    }
}
-- 根据json or table创建context
local showing = true
local context = UI.createContext(rootLayout, globalStyle)
local okbtn = context:findView('test_btn')
okbtn:setActionCallback(UI.ACTION.CLICK, function(id, action)
    -- 主动关闭展示
    context:close()
    showing = false
end)
context:show()
local count = 1
while showing do
    sleep(1000)
    count = count + 1
    if count == 3 then
        local logoLayout = {
            view = 'image',
            class = 'logo', -- 动态创建的image使用到了globalStyle中的'logo'
            src = 'http://www.xxzhushou.cn/statics/images/xxcms5/logo.png',
            style = {
                width = 280,
                height = 76
            }
        }
        local logoView = context:createView(logoLayout)
        -- 将创建的logoView添加到root view中
        context:getRootView():addSubview(logoView)
    end
end

end

function showTips()

local tipsLayout = {
view= 'scroller',
style={
width = 720,
['background-color'] ='#00000000',
['align-items'] = 'center'
},
subviews = {
{
id ='tv_tips',
view = 'text',
class = 'txt',
value='脚本初始化'

}
}
}
local tipsStyle ={

txt={
color ='#41b883',
['background-color'] = '#ffffff',
['font-size'] = 30,
['margin-top'] = 5,
padding = 8

}
}
 context = UI.createContext(tipsLayout, tipsStyle)
 tvTips = context:findView('tv_tips')



end

function setTips(tips)
--	context:show()
--   tvTips:setAttr('value',tips)
--   sleep(1000)
--    context:close()

end