
local isFight = false
local canClick = true
--搜索野怪||叛军 isMonster = true 野怪 false 叛军
function findMonster(a,isMonster)
	isFight = true
	hospital()
	sleep(3000)
	sysLog("出城")
	go()
	sleep(1000)
	sysLog("搜索")
	sleep(1000)

	sysLog("找到搜索按钮")
	点击事件(657,1071)--点击搜索按钮
	--检测是否有叛军
	chooseType(isMonster);
	sleep(500)

	scrollFindUi(30,Point(298,1194))
	--查找
	searchMonster()
	sysLog("找到野怪")
	sleep(1000)
	点击事件(257,970)
	sleep(4000)
	points = screen.findColors(Rect(240, 1173, 254, 65),
		"0|0|0x158068,85|-7|0x1d5ea0,206|-6|0x225b9d",
		95, screen.PRIORITY_DEFAULT)
	if #points~=0 then --找到出征界面
		sysLog("显示出征界面")
		sleep(500)--默认选择第一队列
		点击事件(389,156)
		sleep(1000)--调出选择框
		点击事件(362,1213)
		sleep(1000)--选择最高等级兵种
		点击事件(369,881)
		sleep(1000)--出征
		点击事件(543,1208)
		sleep(4000)--出征检测
		points = screen.findColors(Rect(240, 1173, 254, 65),
			"0|0|0x158068,85|-7|0x1d5ea0,206|-6|0x225b9d",
			95, screen.PRIORITY_DEFAULT)
		if #points~=0 then --出征失败
			sysLog("出征失败")
			return false
		end
		
	else
		sysLog("未显示出征界面")
		isFight = false
		return false
	end
	
	
	--	end --搜索按钮
	hospital()
	return true
end

function testingFucked()
	go()
	sysLog("休息三分钟")
	local i=0
	while true do
		local num = freeTest(4)
		if num~=0 then
			
		end
		i =i+1
		comBackOrTt()
		if i>=36 then
			break
		end
		sleep(5000)
	end
	
end

function hospital()
	sleep(1000)
	sysLog("医院回城")
	back()
	sleep(1000)--调出快速任务栏
	点击事件(694,573)
	sleep(1000)--调出快速医疗
	点击事件(645,304)
	
	sysLog("点击医院")
	sleep(1000)--点击医院
	点击事件(611,449)
	sleep(1000)
	points = screen.findColors(Rect(235, 1171, 261, 72),
		"0|0|0xb3692f,67|0|0x1f61a3,142|-3|0x1d5fa1,205|-3|0x1e60a2,171|2|0x1c1619,40|1|0x1c191d",
		95, screen.PRIORITY_DEFAULT)
	if #points~=0 then--找到治疗界面
		sysLog("找到治疗界面")
		sleep(1000)--点击治疗
		点击事件(548,1204)
		sleep(1000)--请求帮助
		点击事件(354,452)
	else--关闭快速任务栏
		sysLog("医院无任务")
		点击事件(68,85)
		sleep(2000)
	end--治疗界面
end

function 点击事件(x,y)
	
	local poss = Point(x,y)
	touch.down(1, poss)
	sleep(15)
	touch.up(1, poss)
end
function setCanclick(flg)
	canClick = flg
end

function getfight()
	return isFight
end

--回城
function  back()
	isNotHome = true
	
	while isNotHome do
		testingErrorTips()
		sleep(1000)
		sysLog("回城检测")
		points = screen.findColors(Rect(527, 49, 188, 56),
			"0|0|0x1c8889,12|-37|0x0c2d2b,109|-34|0x0e3331,106|2|0x219595,158|-36|0x0c2d2c,137|2|0x1e9993",
			95, screen.PRIORITY_DEFAULT)
		if #points ~= 0 then --在城外 回城
			sysLog("在城外")
			
			sleep(1000)
			points = screen.findColors(Rect(561, 835, 156, 91),
				"0|0|0x1d150e,0|38|0x1c130d,70|-8|0x1c140d,62|34|0x1b130d",
				95, screen.PRIORITY_DEFAULT)
			sleep(1000)
			if #points~=0 then  --找不到搜索按钮
				sysLog("关闭搜索框")
				点击事件(338,745)
			end
			sleep(1000)
			sysLog("回城")
			点击事件(67,1233)
			isNotHome = false
			return true
		end
		sysLog("检测循环")
		points = screen.findColors(Rect(273, 50, 331, 55),
			"0|0|0x1b1918,74|5|0x437fbd,249|8|0xbf7634",
			95, screen.PRIORITY_LEFT_FIRST+screen.PRIORITY_DOWN_FIRST+screen.PRIORITY_HORIZONTAL_FIRST)
		sleep(2000)
		if #points~=0 then --是否在主界面
			sysLog("在城内，结束")
			
			isNotHome = false
			break
		else
			point = screen.findColors(Rect(527, 49, 188, 56),
				"0|0|0x1c8889,12|-37|0x0c2d2b,109|-34|0x0e3331,106|2|0x219595,158|-36|0x0c2d2c,137|2|0x1e9993",
				95, screen.PRIORITY_DEFAULT)
			if #point ~= 0 then --在城外 回城
				sleep("检测错误，在城外")
				sleep(1000)
				points = screen.findColors(Rect(561, 835, 156, 91),
					"0|0|0x1d150e,0|38|0x1c130d,70|-8|0x1c140d,62|34|0x1b130d",
					95, screen.PRIORITY_DEFAULT)
				if #points~=0 then  --找不到搜索按钮
					sysLog("关闭搜索框")
					点击事件(338,745)
				end
				sleep(1000)
				sysLog("回城")
				点击事件(67,1233)
				isNotHome = false
				
				break
			end
			sleep(2000)
			sysLog("不在主界面，返回上一级")
			点击事件(55,92)
		end
	end
	
end

--出城
function go()
	isNotHome = true
	
	while isNotHome do
		testingErrorTips()
		sleep(2000)
		point = screen.findColors(Rect(527, 49, 188, 56),
			"0|0|0x1c8889,12|-37|0x0c2d2b,109|-34|0x0e3331,106|2|0x219595,158|-36|0x0c2d2c,137|2|0x1e9993",
			95, screen.PRIORITY_DEFAULT)
		if #point ~= 0 then --在城外
			sysLog("在城外")
			points = screen.findColors(Rect(561, 835, 156, 91),
				"0|0|0x1d150e,0|38|0x1c130d,70|-8|0x1c140d,62|34|0x1b130d",
				95, screen.PRIORITY_DEFAULT)
			if #points~=0 then  --找不到搜索按钮
				sysLog("关闭搜索框")
				点击事件(338,745)
			end
			sysLog("结束")
			--点击事件(67,1233)
			isNotHome = false
			break
		end
		sysLog("检测循环")
		points = screen.findColors(Rect(273, 50, 331, 55),
			"0|0|0x1b1918,74|5|0x437fbd,249|8|0xbf7634",
			95, screen.PRIORITY_LEFT_FIRST+screen.PRIORITY_DOWN_FIRST+screen.PRIORITY_HORIZONTAL_FIRST)
		if #points~=0 then --是否在主界面
			sysLog("在主界面,出城，结束")
			sleep(1000)--出城
			点击事件(64,1231)
			sleep(3000)
			isNotHome = false
			break
		else
			point = screen.findColors(Rect(527, 49, 188, 56),
				"0|0|0x1c8889,12|-37|0x0c2d2b,109|-34|0x0e3331,106|2|0x219595,158|-36|0x0c2d2c,137|2|0x1e9993",
				95, screen.PRIORITY_DEFAULT)
			if #point ~= 0 then --在城外
				break
			end
			
			
			
			sleep(2000)
			sysLog("不在主界面，返回上一级")
			点击事件(55,92)
			sleep(2000)
		end
	end
end
--查找野怪
function monster(a)
	sleep(2000)--搜索按钮
	点击事件(61,982)
	sleep(500)--选择叛军
	点击事件(260,1191)
	-- 按等级搜索
	for var =1,a do
		sleep(500)
		点击事件(467,1193)
	end
	--查找
	sleep(2000)
	点击事件(599,1191)
	sleep(3000)
	点击事件(369,586)
	sleep(2000)
	points = screen.findColors(Rect(250, 908, 219, 94),
		"0|0|0xbf7f31,-80|0|0xbb7f31,72|0|0xbd7f31,-55|-49|0x2edbf4",
		95, screen.PRIORITY_DEFAULT)
	if #points~=0 then--找到野怪
		sysLog("找到野怪")
		sleep(1000)--点击攻击
		点击事件(257,970)
		sleep(3000)
	else
		
		
	end --找到野怪
end

function find(flag)
	sleep(500)
	if flag  then
		--选择叛军
		点击事件(260,1191)
	else
		--选择野怪
		点击事件(53,984)
	end
	
end

--返回值说明
--0 叛军机甲都不存在
--1 只存在叛军
--2 叛军机甲都存在
--3 只存在机甲
function tesTingMonster()
	sleep(1000)
	
	point = findColors({121, 928, 223, 1030},
		"0|0|0x0e0e16,56|28|0xbc926f,53|-12|0x1d150d,-11|-32|0xeea3ee,10|-33|0xd779df",
		95, 0, 0, 0)
	
	if #point~=0 then--有机甲
		point = findColors({387, 926, 433, 957},
			"0|0|0xce2e1e,11|0|0xe32d1d,6|-16|0xbdadaa",
			95, 0, 0, 0)
		if #point ~= 0 then
			sysLog("有机甲，有叛军")
			return 2;
		else
			sysLog("有机甲，没叛军")
			return 3;
		end
		
		
	else--没机甲
		point = findColors({242, 929, 312, 978},
			"0|0|0x37200d,27|1|0xafa7a7,28|9|0xdb1b0b",
			95, 0, 0, 0)
		
		if #point==0 then--有叛军
			sysLog("没机甲，有叛军");
			return 1;
		else
			sysLog("没机甲，没叛军");
			return 0;
		end
	end
	
	
	sysLog("没有叛军")
	return false
end





function click(x,y)
	local poss = Point(x,y)
	touch.down(1, poss)
	sleep(15)
	touch.up(1, poss)
end

function testingMachine()
	points = screen.findColors(Rect(13, 932, 93, 99),
		"0|0|0xb93cfe,28|27|0x411799,30|69|0x8b8b8c,-21|69|0xcbc4ba,-39|15|0x281a1f",
		95, screen.PRIORITY_DEFAULT)
	if  #points~=0 then
		sysLog("找到机甲")
		return true
		
	end
	
	return false
end



function testingErrorTips()
	points = screen.findColors(Rect(181, 628, 391, 118),
		"0|0|0x282828,77|7|0x282828,207|1|0x282828,293|2|0x282828,40|-60|0x282828,250|-58|0x282828,143|2|0xf3f3f3",
		95, screen.PRIORITY_DEFAULT)
	if #points~=0 then--叉叉助手停止运行报错
		sysLog("叉叉运行报错")
		click(358,700)--点击确定
	end
	points = screen.findColors(Rect(255, 727, 217, 62),
		"0|0|0x3e6ea7,147|-2|0x3d69a2",
		95, screen.PRIORITY_DEFAULT)
	if #points~=0 then--错误弹窗一
		sysLog("错误弹窗一")
		click(363,759)--点击确定
	end
	points = screen.findColors(Rect(623, 118, 60, 52),
		"0|0|0xff0000,26|-1|0xf70101,11|12|0xff0000,-3|24|0xf50303",
		95, screen.PRIORITY_DEFAULT)
	if #points~=0 then--错误弹窗二
		sysLog("特惠弹窗")
		click(654,142)--点击确定
	end
end


function freeTest(a)
	go()
	sleep(1000)
	points = screen.findColors(Rect(192, 1087, 115, 53),
		"0|0|0x141211,0|37|0x141211,22|14|0x3c6cac,85|12|0x3c67a2",
		95, screen.PRIORITY_DEFAULT)
	if #points==0 then --检测队列是收缩状态
		sysLog("队列为收缩状态")
		sleep(2000)
		sysLog("点击展开")
		click(286,1119)--点击箭头
		sleep(1000)
		return freeTestLoop(a)--空闲队列
		
	else--不是收缩状态
		sysLog("队列不是收缩状态")
		sleep(1000)
		return freeTestLoop(a)--空闲队列
	end--检测队列
	
end
function freeTestLoop(a)
	
	pointsA = screen.findColors(Rect(220, 1093, 86, 42),
		"0|0|0x3b69a8,33|2|0x4175b4,64|1|0x3d6dab",
		95, screen.PRIORITY_DEFAULT)
	
	pointsB = screen.findColors(Rect(218, 1033, 87, 40),
		"0|0|0x3b6baa,32|-2|0x3d67a1,66|-2|0x3b67a1",
		95, screen.PRIORITY_DEFAULT)
	
	pointsC = screen.findColors(Rect(222, 970, 83, 42),
		"0|0|0x38619d,33|3|0x3e6fab,68|0|0x3a639b",
		95, screen.PRIORITY_DEFAULT)
	
	pointsD = screen.findColors(Rect(223, 913, 81, 36),
		"0|0|0x39639f,32|2|0x3e6eaa,68|1|0x3c68a4",
		95, screen.PRIORITY_DEFAULT)
	
	pointsE = screen.findColors(Rect(219, 851, 85, 38),
		"0|0|0x3966a6,33|0|0x3e6da8,69|0|0x3c6aa8",
		95, screen.PRIORITY_DEFAULT)
	
	if #pointsA==0 then--所有队列空闲
		return a
	else--至少一个队列任务中
		if #pointsB==0 then --B队列检测
			
			return a-1
		else
			if #pointsC==0 then --C队列检测
				return a-2
			else
				if #pointsD==0 then --D队列检测
					return a-3
				else
					if #pointsE==0 then --E队列检测
						return a-4
					else
						return 0
					end--E队列检测
				end--D队列检测
				
				
			end--C队列检测
		end--B队列检测
		
	end--所有队列空闲
	
	
	return 0
	
end

function searchMonster()
	
	while true do
		--查找
		sleep(500)
		点击事件(599,1191)--点击查找按钮
		sleep(3000)
		点击事件(369,586)--点击屏幕中央
		sleep(1000)
		points = screen.findColors(Rect(250, 908, 219, 94),
			"0|0|0xbf7f31,-80|0|0xbb7f31,72|0|0xbd7f31,-55|-49|0x2edbf4",
			95, screen.PRIORITY_DEFAULT)
		
		if #points~=0 then--找到野怪
			break
		else
			sysLog("未找到野怪")
			点击事件(657,1071)--点击搜索按钮
			sleep(1000)
			点击事件(63,1187)
			sleep(500)
		end
	end
end

function scrollFindUi(a,pos)
	--拖动到末尾
	
	touch.down(1, pos)
	for i = 1, 6 do
		sleep(15)
		-- 模拟手指每次移动递增(3, 2)像素
		pos = pos + Point(a * i, 0)
		touch.move(1, pos)
	end
	sleep(15)
	-- 模拟抬起手指
	touch.up(1, pos)
	sleep(1000)
end
function chooseType(flag)
	--返回值说明
	--0 叛军机甲都不存在
	--1 只存在叛军
	--2 叛军机甲都存在
	--3 只存在机甲
	
	local resultType = tesTingMonster();
	if resultType==0 then
		点击事件(68,979)
	elseif resultType==1 then
		if flag then
			点击事件(292,985)
			
		else
			点击事件(68,979)
		end
		
	elseif resultType==2 then
		if flag then
			点击事件(415,987)
		else
			点击事件(175,984)
		end
	else
		点击事件(171,987)
	end
	
	
end
