MultScreenSupport =
{
	username = "";
	password ="";
	game_Rsp =16/9;
	dev_Rs = {1280,720};
	current_Rs ={};
	points = {};
	point_point ={};
	point_findColor ={};
	points_response ={};
}

MultScreenSupport.TYPE_POINT =1;

function MultScreenSupport:new(user,psw,game_Rsp,dev_Rs)
	
	if game_Rsp==nil or type(game_Rsp)~='number' then
		error('游戏开发分辨率必须传入例如：16/9 必须为number类型');
	end
	
	if dev_Rs==nil or type(dev_Rs)~='table' then
		error('开发分辨率必须传入例如：{1280,720} 必须为table类型');
	end
	
	local o = o or {}
	setmetatable(o, self)
	self.__index = self
	self.username = user or 'unknow';
	self.password = psw or 'unknow';
	self.game_Rsp = game_Rsp or 16/9
	self.dev_Rs = sortTable(dev_Rs) or nil
	
	
	---init parmas
	width,height = getScreenSize();
--	width,height = 400,400;
	
	self.current_Rs = sortTable({width,height});
	
	return o
	
end

function MultScreenSupport:add(key,value)
	self.points[key] = value;
	value.n = key;
	--	sysLog(value.c.."?")
	if value.c==Base.POINT then
		self.point_point[#self.point_point+1] = value;
	elseif value.c==Base.FINDCOLORPARMS then
		self.point_findColor[#self.point_findColor+1] = value;
	end
	
end

function MultScreenSupport:multChange()
	
	local pointsData  = json:encode(self.point_point);
	local findColorsData  = json:encode(self.point_findColor);
	local httpParams = {};
	httpParams["p"] = pointsData;
	httpParams["f"] = findColorsData;
	httpParams["game_Rsp"] = self.game_Rsp..'';
	httpParams["dev_Rs"] = self.dev_Rs[1]..','..self.dev_Rs[2];
	httpParams["current_Rs"] = self.current_Rs[1]..','..self.current_Rs[2];
	httpParams["username"] = self.username;
--	httpParams["password"] = self.password;
	httpParams["password"] = lo_md5.sumhexa(self.password);
	
	--	local params =
	--	'p='..pointsData..
	--	'&f='..findColorsData..
	--	'&game_Rsp='..self.game_Rsp..
	--	'&dev_Rs='..self.dev_Rs[1]..','..self.dev_Rs[2]..
	--	'&current_Rs='..self.current_Rs[1]..','..self.current_Rs[2]..
	--	'&user='..self.user..
	--	'&psw='..lo_md5.sumhexa(self.psw);
	localStr = json:encode(httpParams)
--		sysLog(localStr)
	
	local response_body = {}
	local res, code = http.request{
		url = 'http://www.scriptschool.cn/freegame/run',
		method = "POST",
		--		body = json.encode(httpParams),
		headers =
		{
			['Content-Type'] = 'application/json',
			['Content-Length'] = #localStr,
		},
		source = ltn12.source.string(localStr),
		sink = ltn12.sink.table(response_body)
	}
	
	res = table.concat(response_body)  
	
	
	if code == 200 then
		sysLog(response_body[1]);
		self.p_point_response = json:decode(response_body[1])
		
		if self.p_point_response.code ==1 then
			
			local data = json:decode(self.p_point_response.data);
			
			if(data.points~=nil) then
				for k,v in pairs(data.points) do
					self.points_response[v.n] = v;
				end
			end
			
			if(data~=nil) then
				for k,v in pairs(data.findColors)do
					self.points_response[v.n] = v;
				end
			end
			sysLog('FREEGAME:转换全分辨率成功 分辨率:['..self.dev_Rs[1]..','..self.dev_Rs[2]..'] -> ['..self.current_Rs[1]..','..self.current_Rs[2]..']')
		else
			dialog('转色错误：'..self.p_point_response.msg)
		end
		
	else
		
		if response_body~=nil and response_body[1]~=nil then
			local errorMSG = json:decode(response_body[1]);
			if errorMSG~=nil and errorMSG.message~=nil then
				sysLog('FreeGame提示\n转色错误：'..errorMSG.message)
				dialog('FreeGame提示\n转色错误：'..errorMSG.message)
--				error('FreeGame提示\n转色错误：'..errorMSG.message);
--				os.exit();
			else
				sysLog('FreeGame提示\n转色错误,请联系管理员.\n错误码:'..code)
				dialog('FreeGame提示\n转色错误,请联系管理员.\n错误码:'..code)
				error('FreeGame提示\n转色错误,请联系管理员.\n错误码:'..code);
--				os.exit();
			end
		else
			sysLog('FreeGame提示\n转色错误,请联系管理员.\n错误码:'..code)
			dialog('FreeGame提示\n转色错误,请联系管理员.\n错误码:'..code)
--			error('FreeGame提示\n转色错误,请联系管理员.\n错误码:'..code);
--			os.exit();
		end
		
	end
	
	
end

function MultScreenSupport:get(key)
	return self.points_response[key];
end

function sortTable(排序分辨率)
	if 排序分辨率[1] >排序分辨率[2] then
		return 排序分辨率;
	end
	
	local 分辨率替换 = 排序分辨率[1];
	排序分辨率[1] = 排序分辨率[2];
	排序分辨率[2] = 分辨率替换;
	
	return 排序分辨率;
	
end


function MultScreenSupport:getNotch()
	local product = getSystemProperty('ro.build.product');
	sysLog(product)
	return product;
end


---------------------------domian

Base = 
{
	c =0;
	a =0;
	n = "";
}

Base.POINT = 1;
Base.RECT = 2;
Base.FINDCOLORPARMS = 3;

function Base:new()
	local o = {}
	setmetatable(o, self)
	self.__index = self
	return o
	
end

findcolor =
{
	rect = {};
	colors = "";
}
function findcolor:new(a,rect,colors)
    local o = Base:new();
	setmetatable(o, self)
	o.rect = rect or {};
	o.colors = colors or {};
	
	o.c = Base.FINDCOLORPARMS;
	o.a = a;
	---init parmas
	return o
end

point =
{
	x = 0;
	y = 0;
}

function point:new(a,pointxy)
    local o = Base:new();
	setmetatable(o, self)
	o.x = pointxy[1] or 0
	o.y = pointxy[2] or 0
	
	o.c = Base.POINT;
	o.a = a;
	---init parmas
	
	return o
end