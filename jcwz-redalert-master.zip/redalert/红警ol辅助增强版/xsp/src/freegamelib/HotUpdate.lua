-- Author: FreeGame 【游自在】
-- FreeGame QQGroup:908536305
print('hot update lib')
json = require (libpF..'JSON');
http = require (libpF..'http');
lo_md5 = require(libpF..'md5')

hotupdate={
	username;
	passWord;
}

function hotupdate.init(userName,passWord)
	hotupdate.username = userName;
	hotupdate.password = passWord;
end

--此方法仅适用于 xxide 2.0.1.7 及以下版本
function hotupdate.require(key)
	local cc = hotupdate.getValue(key);
	local actionMethod = loadstring(cc);
	if actionMethod ~=nil then
		actionMethod();
	end
end

--function hotupdate.change
function hotupdate.getValue(key)
	
	local httpParams = {};
	
	httpParams["username"] = hotupdate.username;
	httpParams["password"] = lo_md5.sumhexa(hotupdate.password);
	httpParams["key"] = key;
	
	localStr = json:encode(httpParams)
	sysLog(localStr)
	

	local response_body = {}
	local res, code = http.request{
		url = 'http://www.scriptschool.cn/freegame/hotUpdate',
		method = "POST",
		--		body = json.encode(httpParams),
		headers =
		{
			['Content-Type'] = 'application/json',
			['Content-Length'] = #localStr,
		},
		source = ltn12.source.string(localStr),
		sink = ltn12.sink.table(response_body)
	}
	
	res = table.concat(response_body)
	
	local hotTable = json:decode(response_body[1]);
	
	if code == 200 then
		
		if hotTable~=nil and hotTable.code == 1 then
			return hotTable.data;
		elseif hotTable==nil then
			sysLog(hotTable.msg)
		else
			sysLog('hot update 未知错误')
		end
		
	end
	
	if hotTable~=nil then
		sysLog(hotTable.message)
	end
	
	return "";
	
end