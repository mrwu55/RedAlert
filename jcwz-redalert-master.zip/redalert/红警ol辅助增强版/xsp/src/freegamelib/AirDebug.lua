log('欢迎使用FreeGame-AirDebug 空中调试功能')


AirDebug = {}


function AirDebug.init(user,password)
	hotupdate.init(user,password);
	
	local debugSwitch = hotupdate.getValue('debug') or false;
	log(debugSwitch);
	if debugSwitch~=nil and debugSwitch == "true" then
		local isRun = true;
		while isRun do
			rec,result = showUI('airdebug.json');
			if rec ==1 then
				local key = result.ed_key;
				if key then
					hotupdate.require(key);
				else
					dialog('必须输入key值')
				end
			else
				isRun = false;
			end
		end
	else
		log('类库 中没有配置 debug 字段，视为关闭空中调试')
	end
end
return AirDebug;



