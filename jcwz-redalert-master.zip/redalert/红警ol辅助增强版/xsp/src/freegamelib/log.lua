
local logSwitch = true;
function log(msg)
	if type(msg) =='boolean' then
		logSwitch = msg;
		return;
	end
	
	if logSwitch then
		local mParent = debug.getinfo(2);
		if mParent~=nil then
			local mParent_name = mParent.source;
			local mParent_line = mParent.currentline;
			print(mParent_name..'['..mParent_line..']:'..msg)
		else
			print(msg)
		end
	end
end

