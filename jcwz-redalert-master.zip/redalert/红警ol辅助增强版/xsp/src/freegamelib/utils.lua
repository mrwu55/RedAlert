
function random(x,f)
   local r = math.random(x-f,x+f);
   return r;
end