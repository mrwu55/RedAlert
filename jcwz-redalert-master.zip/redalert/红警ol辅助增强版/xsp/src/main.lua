require "LoopTask"
require "TaskOften"

--collect(5)

function startRun()
--初始化 freegame框架
initFreeGame();
sleep(1000);
--help();
--readMessage();
--unionTasks();
--getResource();
--airDrop();
--solider(5,11);
outSideGetRes(5);
--cjSpeedUp();
--resoureceSupply();
--vipShop()

end

startRun();

