
fg= require 'freegame'
function click(x,y)
	local poss = Point(x,y)
	touch.down(1, poss)
	sleep(15)
	touch.up(1, poss)
end
function clickPint(pos)
	
	touch.down(1, pos)
	sleep(15)
	touch.up(1, pos)
end
function clickWithColor(v)
	local result = getPoints(v)
	--  point ~= Point.INVALID
	if result then  
		
		click(v.tap[1],v.tap[2])
		
	end
	
	return result
end
function clickWithColors(v)
	local result = getPoints(v)

	if result then  
		
		click(v.tap[1],v.tap[2])
		
	end
	return result
end
--findcolor
function getPoint(v)
	point = screen.findColor(Rect(v[2][1],v[2][2],v[2][3],v[2][4]),
		v[3],
		v[4], screen.PRIORITY_DEFAULT)
	return point
end
--findcolors
function getPoints(v)
point = findColors({v[2][1],v[2][2],v[2][3],v[2][4]}, 
v[3],
v[4], 0, 0, 0)
if #point ~= 0 then
return true
end
return false
end
function getUi(list)
	for k,v in pairs(list) do
		point = getPoint(v)
		if point ~= Point.INVALID then
			sysLog(v[1])
			return v[1]
		end
	end
	return nil
end
--a 每次滑动像素
--pos 起始点位置
--flag true 横向  false纵向
function scrollScreen(a,x,y,flag)
	--拖动到末尾
	
	touch.down(1,x,y)
	mSleep(50)
	if flag then
		touch.move(1, x+a,y)
		sysLog("横向滑动")
		mSleep(50)
		-- 模拟抬起手指
		touch.up(1, x+a,y)
	else
		sysLog("纵向滑动")
		touch.move(1, x,y+a)
		mSleep(50)
		-- 模拟抬起手指
		touch.up(1, x,y+a)
	end
	sleep(1000)
	click(allClickPoints[13].tap[1],allClickPoints[13].tap[2])

	
end
-- 模拟滑动操作，从点(x1, y1)划到到(x2, y2)
function swip(x1,y1,x2,y2)
    local step, x, y, index = 20, x1 , y1, math.random(1,5)
    touchDown(index, x, y)

    local function move(from, to) 
      if from > to then
        do 
          return -1 * step 
        end
      else 
        return step 
      end 
    end
	while (math.abs(x-x2) >= step) or (math.abs(y-y2) >= step) do
        if math.abs(x-x2) >= step then x = x + move(x1,x2) end
        if math.abs(y-y2) >= step then y = y + move(y1,y2) end
        touchMove(index, x, y)
        mSleep(20)
    end
	touchMove(index, x2, y2)
    mSleep(30)
    touchUp(index, x2, y2)
end
function goOrBack(flag)
	
	while true do
		testingErrorTips()
		local uiName = getUi(uiMainList)
		sysLog("goOrBack-->循环检测")
		if uiName ==nil then
			sysLog("goOrBack-->不在城内外，返回")
			click(allClickPoints[1].tap[1],allClickPoints[1].tap[2])
		else
			sysLog("goOrBack-->返回值："..uiName)
			if flag then--回城
				if uiName=="城外" then
					sysLog("goOrBack-->在城外，回城")
					click(allClickPoints[2].tap[1],allClickPoints[2].tap[2])
					sleep(2000)
				end
				break
			else --出城
				if uiName=="城内" then
					sysLog("goOrBack-->在城外，出城")
					click(allClickPoints[2].tap[1],allClickPoints[2].tap[2])
					sleep(2000)
				end
				break
			end
			
		end
		sleep(1000)
	end--循环
	
end
function testingErrorTips()
	
	local result = getUi(uiErrorList)
	if result~=nil then
		if result =="叉叉报错" then
			click(allClickPoints[3].tap[1],allClickPoints[3].tap[2])
		elseif result == "特惠弹窗" then
			click(allClickPoints[5].tap[1],allClickPoints[5].tap[2])
		else--错误弹窗一
			click(allClickPoints[4].tap[1],allClickPoints[4].tap[2])
		end
	end
	
end

function getFreeNum()
	goOrBack(false);
	local freeNum = 0;
	if getPoint(queueList[1])==Point.INVALID then
		sysLog("展开队列")
		click(287,1118)
		sleep(1000)
	end
	for k,v in pairs(queueList) do
		point = getPoint(v);
		if point == Point.INVALID then
			freeNum = freeNum+1;
		end
		
	end
	sysLog("最大空闲队列："..freeNum)
	return freeNum
end

function collect(num)
	
	while true do
		--找到搜索界面
		if getPoint(outsideUiList[1])~=Point.INVALID then
			sysLog("找到搜索界面");
			click(348,801);
			sleep(1000);
		end
		--计算真实的空闲队列
		local freeQueue = getFreeNum();
		local collectNum = num-(5-freeQueue);
		sysLog("真实的空闲队列："..collectNum);
		if collectNum >0 then
			click(657,1071)
			sleep(2000)
			findResource(1,8,false)
			break
		else
			
			break
		end
	end
	
end

function scrollFindUi(a)
	--拖动到末尾
	local pos = Point(364,968)
	touch.down(1, pos)
	for i = 1, 6 do
		sleep(15)
		-- 模拟手指每次移动递增(3, 2)像素
		pos = pos + Point(a * i, 0)
		touch.move(1, pos)
	end
	sleep(15)
	-- 模拟抬起手指
	touch.up(1, pos)
	sleep(1000)
end
function findResource(resourceType,grade,needUnion)
	click(651,1067)
	sleep(1000)
	scrollFindUi(30);
	local findName = getUi(outsidePointList);
	--默认为矿石A
	local resourcePoints={Point(410,989),Point(533,984),Point(646,980) }
	if findName ~=nil then
		if findName=="矿石B" then
			resourcePoints={Point(289,988),Point(407,992),Point(525,991) }
		elseif findName=="矿石C" then
			scrollFindUi(-30)
			resourcePoints={Point(289,988),Point(407,992),Point(525,991) }
		else--
			sysLog("默认矿石A")
		end
		local point = resourcePoints[resourceType]
		
		findWithGrade(point,grade)
		
		
	else
		sysLog("未找到资源位置")
	end
	
	
end
function findWithGrade(point,grade)
	clickPint(point)
	sleep(1000)
	--先将等级降为1级
	click(146,1190)
	sleep(1000)
	for var = 1,3 do
		sysLog("点击次数")
		click(68,1190)
		sleep(500)
	end
	sleep(1000)
	for var =1,grade-1 do
		click(469,1194)
		sleep(500)
	end
	--正在搜索界面
	if getPoint(outsideUiList[1])~=Point.INVALID then
		while true do
			sysLog("查找资源");
			click(597,1196);
			sleep(1000);
			
			if getPoint(outsideUiList[2])~=Point.INVALID then
				sysLog("找到资源，结束")
				break
			else
				sysLog("降一级资源")
				--降一级查找
				click(68,1190)
				sleep(1000)
			end
		end
		
	end
end
function initFreeGame()
	框架初始化配置={
		横屏游戏 = false, --横屏游戏 = true,竖屏游戏 = false;
		点击痕迹 ={true,'click.png'};--配置true 点击后提示点击位置
		--	如果不需要支持全分辨率，只支持同比分辨率缩放，则需要配置以下参数。
		--	同比分辨率支持 = {
		--		是否勉强运行 = true,
		--		--参数1为屏幕比例,参数2位游戏屏幕缩放分辨率，参数3为对应的特征库
		--		{9/16,{720,1280},'p16-9'},{4/3,{1080,2244},'p4-3'},{4000/3999,{4000/3999},'p4000-3999'}}
		--	},
		全分辨率支持 ={
			是否开启 = true,
			账号 = "1126294330",
			密码 = "111111",
			游戏引擎比 = 16/9,
			开发分辨率 = {1280,720},
			特征库 = "p-all",
			额外转换 = function(mult)
				--增加一个点 key值，和value值,转换为全分辨率下的点。
				mult:add("点1",point:new(7,{35,627}));
				--增加Findcolor参数（支持绝对范围和相对范围）将它转换为全分辨率下的findcolor
				--			 mult:add("范围特征1",findcolor:new(8,{388, 584, 473, 615}, "0|0|0xd3c8a3,16|0|0xd4c597"));
			end
		},
		--当框架需要比色的时候会回调该方法，参数o为色点特征对象
		比色回调方法 = function(o)
			x, y = findColor(
				o[2],
				o[3],
				o[4],0,0,0)
			return x,y;
		end,
		动作回调方法 = function(point,o)
			
			if o.tap~=nil then
				fg.点击(o.tap[1],o.tap[2])
				log('-----已经点击了'..o.tap[1]..','..o.tap[2])
				return;
			end
			fg.点击(point.x,point.y);
			log('-----已经点击了')
		end
	}
	
	return fg.init(框架初始化配置)
end

