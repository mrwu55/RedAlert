require 'lib'
--读取邮件
function readMessage()
	goOrBack(true);
	local result = clickWithColor(mainPoints[2]);
	sleep(1000);
	if result==false then
		return;
	end
	for pos,page in pairs(readMessege) do
		
		if pos<5  then
			if clickWithColor(page) then
				sysLog("readMessage()找到点-->"..page[1]);
				sleep(1000)
				if pos==1  then
					click(allClickPoints[6].tap[1],allClickPoints[6].tap[2]);
				end
				
				click(allClickPoints[1].tap[1],allClickPoints[1].tap[2]);
				sleep(2000)
			else
				sysLog("readMessage()未找到点-->"..page[1]);
			end
		else
			if clickWithColor(page) then
				sysLog("readMessage()找到点-->"..page[1]);
				sleep(2000)
				if pos==5 then
					sysLog("读取个人消息")
					click(allClickPoints[7].tap[1],allClickPoints[7].tap[2]);
				else
					click(allClickPoints[6].tap[1],allClickPoints[6].tap[2]);
					
				end
				sleep(2000)
				click(allClickPoints[1].tap[1],allClickPoints[1].tap[2]);
				sleep(1000)
				click(allClickPoints[1].tap[1],allClickPoints[1].tap[2]);
				sleep(2000)
				
			else
				sysLog("readMessage()未找到点-->"..page[1]);
			end
		end
		
	end
	sleep(2000);
	goOrBack(true);
	
end
--联盟帮助
function help()
	sysLog("help()-->联盟帮助");
	goOrBack(true);
	sleep(2000);
	clickWithColor(mainPoints[1]);
	sleep(1500);
end
--联盟任务
function unionTasks()
	goOrBack(true);
	click(allClickPoints[8].tap[1],allClickPoints[8].tap[2]);
	unionDonate();
	sleep(1500);
	
	for pos,page in pairs(unionTask) do
		if pos > 3 then
			sysLog("unionTasks()-->"..pos.."退出");
			break;
		end
		if clickWithColor(page) then
			sleep(1000);
			if pos==1 then
				clickWithColor(unionTask[6])
				sleep(1500)
			end
			if pos~=3 then
				click(allClickPoints[6].tap[1],allClickPoints[6].tap[2]);
			else
				clickWithColor(unionTask[7]);
				sleep(2000);
				if clickWithColor(unionTask[8]) then
					sysLog("可以领取宝箱")
					sleep(2000);
					click(allClickPoints[11].tap[1],allClickPoints[11].tap[2]);
					sleep(2000);
					click(allClickPoints[11].tap[1],allClickPoints[11].tap[2]);
				end
				sleep(1500)
				if clickWithColor(unionTask[9]) then
					sysLog("可以帮助宝箱")
					sleep(2000);
					click(allClickPoints[11].tap[1],allClickPoints[11].tap[2]);
					sleep(2000);
					click(allClickPoints[11].tap[1],allClickPoints[11].tap[2]);
				end
			end
			sleep(1000)
			click(allClickPoints[1].tap[1],allClickPoints[1].tap[2]);
		end
		sleep(2000);
	end
end
function unionDonate()
	sleep(1500);
	click(allClickPoints[9].tap[1],allClickPoints[9].tap[2]);
	sleep(2000);
	click(allClickPoints[10].tap[1],allClickPoints[10].tap[2]);
	sleep(2000);
	while true do
		if clickWithColor(unionTask[4]) then
			
			sleep(1500);
			local point = getPoint(unionTask[5]);
			if point ~= Point.INVALID then
				sysLog("unionDonate()-->科技捐献重置界面");
				click(allClickPoints[1].tap[1],allClickPoints[1].tap[2]);
				sleep(2000);
				break;
				
			end
		else
			break;
		end
		
	end
	click(allClickPoints[1].tap[1],allClickPoints[1].tap[2]);
	sleep(2000);
	click(allClickPoints[1].tap[1],allClickPoints[1].tap[2]);
	
end
--收取资源
function getResource()
	goOrBack(false);
	goOrBack(true);
	local x =allClickPoints[12].tap[1];
	local y = allClickPoints[12].tap[2];
	local point = Point(allClickPoints[12].tap[1],allClickPoints[12].tap[2]);
	sleep(1000);
	swip(x,y,x-600,y);
	sleep(1500);
	swip(x,y,x-600,y);
	sleep(1000);
	swip(x,y,x,y+600);
	sleep(1000);
	swip(x,y,x,y-300);
	sleep(1000);
	click(getResourcePoint[1].tap[1],getResourcePoint[1].tap[2]);
	sleep(1000);
	click(getResourcePoint[2].tap[1],getResourcePoint[2].tap[2]);
	sleep(1000);
	click(getResourcePoint[3].tap[1],getResourcePoint[3].tap[2]);
	sleep(1000);
	click(getResourcePoint[4].tap[1],getResourcePoint[4].tap[2]);
end
--空投补给
function airDrop()
	sysLog("airDrop()-->运行");
	goOrBack(true);
	sleep(1000);
	click(fastBtns[1].tap[1],fastBtns[1].tap[2]);
	sleep(1000);
	click(fastBtns[4].tap[1],fastBtns[4].tap[2]);
	sleep(1000);
	click(fastBtns[5].tap[1],fastBtns[5].tap[2]);
	sleep(1000);
	clickWithColor(mainPoints[3]);
end
--部队训练 soliderType  4战车工厂 3兵营 1坦克工厂 2空指部 5城防
function solider(soliderType,grade)
	--切换后勤
	changeStrategy(0);
	sleep(1000);
	goOrBack(true);
	sleep(1000);
	--快捷界面
	click(fastBtns[1].tap[1],fastBtns[1].tap[2]);
	sleep(1000);
	--快捷训练界面
	click(fastBtns[2].tap[1],fastBtns[2].tap[2]);
	sleep(1000);
	--检测空闲训练队列
	local resultFree = clickWithColor(soliderPoints[soliderType]);
	--按等级训练
	if resultFree then
		--将等级降为一
		local isLow = true;
		while isLow do
			sleep(1000);
			isLow = clickWithColor(soliderPoints[6]);
		end
		for i=grade,1,-1 do
			sysLog("for循环");
			sleep(1000);
			click(strategy[10].tap[1],strategy[10].tap[2]);
		end
		sleep(1000);
		--点击训练
		click(strategy[11].tap[1],strategy[11].tap[2]);
	end
	
end

-----------------------------------超过30分钟循环任务--------------------------------

--采集加速
function cjSpeedUp()
	goOrBack(true);
	goOrBack(false);
	click(allClickPoints[14].tap[1],allClickPoints[14].tap[2]);
	sleep(1000);
	click(outSidePoints[1].tap[1],outSidePoints[1].tap[2]);
	sleep(1000);
	local result = clickWithColor(thirtyMTsks[1]);
	sleep(1500);
	if result  then
		swip(outSidePoints[2].tap[1],outSidePoints[2].tap[2],outSidePoints[3].tap[1],outSidePoints[3].tap[2]);
		sleep(1500);
		local result8 = clickWithColor(thirtyMTsks[2]);
		if result8== false then
			clickWithColor(thirtyMTsks[3]);
		end
	end
end

--vipShop
function vipShop()
	goOrBack(true);
	sleep(1000);
	click(allClickPoints[15].tap[1],allClickPoints[15].tap[2]);
	sleep(1000);
	click(allClickPoints[16].tap[1],allClickPoints[16].tap[2]);
end

--资源补给
function resoureceSupply()
	changeStrategy(1);
	sleep(2000);
	--检测已解锁的战略技能
	local resultNum = testUnlockNum();
	sysLog("resoureceSupply()--解锁战略数-->"..resultNum);
	if resultNum==3 then --已解锁3个
		click(strategy[7].tap[1],strategy[7].tap[2]);
		sleep(1000);
		click(strategy[9].tap[1],strategy[9].tap[2]);
		sleep(1000);
		click(strategy[8].tap[1],strategy[8].tap[2]);
		sleep(1000);
		click(strategy[9].tap[1],strategy[9].tap[2]);
	elseif (resultNum==2 or resultNum==1) then--两个或一个
		click(strategy[6].tap[1],strategy[6].tap[2]);
		sleep(1000);
		click(strategy[9].tap[1],strategy[9].tap[2]);
		sleep(1000);
		click(strategy[7].tap[1],strategy[7].tap[2]);
		sleep(1000);
		click(strategy[9].tap[1],strategy[9].tap[2]);
	end
end


function testStrategy()
	goOrBack(true);
	sleep(1000);
	click(strategy[1].tap[1],strategy[1].tap[2]);
	sleep(1000);
	local resultTwoTest = getUi(strategyTest);
	if resultTwoTest ~=nil then
		
		if resultTwoTest == "底部两个按钮" then
			return 2;
		else
			return 1;
		end
	else
		return 0;
	end
	
end

--战略切换 changeType： 0 后勤 1 工业 2军事
function changeStrategy(changeType)
	local resultType = testStrategy();
	sleep(1000);
	sysLog("changeStrategy()当前战略-->"..resultType.."--需要切换战略"..changeType);
	if  changeType ==resultType then
		return
	end
	
	if  resultType == 2  then
		if changeType ==0 then
			click(strategy[5].tap[1],strategy[5].tap[2]);
		else
			click(strategy[4].tap[1],strategy[4].tap[2]);
		end
	elseif resultType==1 then
		if changeType == 0 then
			click(strategy[5].tap[1],strategy[5].tap[2]);
		else
			click(strategy[2].tap[1],strategy[2].tap[2]);
		end
	else
		if changeType == 1 then
			click(strategy[3].tap[1],strategy[3].tap[2]);
		else
			click(strategy[2].tap[1],strategy[2].tap[2]);
		end
	end
	
end
--返回已解锁战略技能个数
function testUnlockNum()
	local resultA = getPoints(industry[1]);
	if resultA==false then
		return 3;
	end
	local resultB = getPoints(industry[2]);
	if resultB==false then
		return 2;
	end
	local resultC = getPoints(industry[1]);
	if resultC == false then
		return 1;
	end
	return 0;
end
