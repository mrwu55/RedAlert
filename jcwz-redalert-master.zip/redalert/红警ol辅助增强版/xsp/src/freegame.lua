
libpF = 'freegamelib.'
require (libpF..'log');
require (libpF..'utils');
require (libpF.."MultScreenSupport");
require (libpF.."HotUpdate");
require (libpF.."AirDebug");
json = require (libpF..'JSON');
http = require (libpF..'http');
lo_md5 = require(libpF..'md5')

local freegame = {config =nil;};

local pageList;

function freegame.init(config)
	freegame.config = config;
	local gameOre;
	if config ~= nil then
		----屏幕朝向
		if config.横屏游戏~=nil then
			if config.横屏游戏 then
				init("0", 1); --横屏游戏
				gameOre = '横屏游戏';
			else
				init("0", 0); --竖屏游戏
				gameOre = '竖屏游戏';
			end
		else
			error('框架初始化配置中.横屏游戏 必须配置');
		end
		----同比缩放分辨率适配
		local scaleDes = nil;
		if config.同比分辨率支持~=nil then
			local w,h =getScreenSize();
			for k,v in pairs(config.同比分辨率支持) do
				if type(v) == "table" then
					if type(v[1]) == 'number'then
						if w/h == v[1] or h/w == v[1] then
							pageList = require (v[3]) --加载对应的特征库
							setScreenScale(v[2][1],v[2][2]);
							scaleDes = '当前分辨率['..w..'/'..h..'] 匹配到特征库['..v[3]..']-缩放至->['..v[2][1]..','..v[2][2]..']'
							break;
						end
					end
				end
			end
			
			if scaleDes ==nil then
				if config.同比分辨率支持.是否勉强运行 then
					toast('当前分辨率找不到匹配的色库，将继续勉强运行')
					scaleDes ='当前分辨率['..w..'/'..h..'] 无匹配色库,勉强运行'
				else
					dialog('很抱歉，脚本暂不支持此分辨率')
					return false;
				end
			end
			
			
		end
		
		if config.全分辨率支持~=nil and config.全分辨率支持.是否开启 then
			scaleDes = '全分辨率支持开启-匹配库为['..config.全分辨率支持.特征库..']';
			pageList = require (config.全分辨率支持.特征库)
			freegame.全分辨率点转换(pageList,config);
		end
		
		
		log('\n--初始化FreeGame框架成功:\n'..gameOre..'\n'..scaleDes)
		return true;
	else
		error('init方法中 框架初始化参数,必须配置');
	end
	
end

--[[
运行函数参数
t 为运行流程
times 为运行次数,为nil 时无限循环运行,填写数字时，则运行n次。

--]]
function freegame.运行(t,times)
	local isRun = true;
	--效果相同 end
	while isRun do
		local currentPage = freegame.获取当前游戏界面();
		if currentPage ~=nil then
			for k,v in pairs(t) do
				if v[1] ==nil or (currentPage.f~=nil and currentPage.f[1] == v[1].f[1]) then
					log(''..v[2][1])
					if type(v[3])=="number" then
						radomTime = random(v[3],150);
					elseif v[3]~=nil then
						radomTime = math.random(v[3][1],v[3][2]);
					end
					
					if mTime() - (v['lastActionTime'] or 0) < (radomTime or random(1000,150)) then log('跳过') break; end
					keepScreen(true)
					local x,y = freegame.config.比色回调方法(v[2]);
					keepScreen(false);
					if x>-1 or y>-1 then
						log('匹配到特征:'..v[2][1])
						local isSkipActon = false;
						if v[5]~=nil then
							local isExitJob,actionS=v[5]();
							isSkipActon = actionS;
							if isExitJob then isRun = false; log('运行前检测到，并退出流程') return end;
						end
						
						if not isSkipActon then
							freegame.config.动作回调方法({x=x,y=y},v[2]);
							v['lastActionTime'] = mTime();
							if v[4]~=nil then
								local isExitJob=v[4]();
								if isExitJob then isRun = false; log('运行后退出流程') return end;
							end
						else
							log('运行前通知跳过执行动作')
						end
						
					else
						if v[6]~=nil then
							if v[6]() then isRun =false; log('特征没有检测到,退出运行流程') return end
						end
					end
				end
			end
		else
			
			--		break;
		end
		mSleep(random(1000,150))
		
		if times~=nil then
			times = times-1;
			if times<1 then
				isRun = false;
			end
		end
		
	end
end


function freegame.全分辨率点转换(pageList,config)
	mult = MultScreenSupport:new(config.全分辨率支持.账号,config.全分辨率支持.密码,config.全分辨率支持.游戏引擎比,config.全分辨率支持.开发分辨率);
	
	for k,v in pairs(pageList) do
		
		
		for pos,page in pairs(v) do
			if(#page)>2 then
				
				mult:add(page[1]..'page',findcolor:new(page[2][5],{page[2][1], page[2][2], page[2][3], page[2][4]}, page[3]));
				if page.tap~=nil then
					if (#page.tap)>2 then
						mult:add(page[1]..'tap',point:new(page.tap[3],{page.tap[1],page.tap[2]}))
					else
						error(page[1]..' 有tap 属性，但tap 没有配置锚点，无法支持全分辨率缩放，锚点格式{x,y,锚点}')
					end
				end
			
			else
				
				mult:add(page[1],point:new(page.tap[3],{page.tap[1],page.tap[2]}))
			end
		end
		
		
	end
	
	if config.全分辨率支持.额外转换~=nil then config.全分辨率支持.额外转换(mult) end
	
	mult:multChange();
	
	for k,v in pairs(pageList) do
		
		for pos,page in pairs(v) do
			if(#page)>2 then
				local basep =	mult:get(page[1]..'page')
				if basep.c == Base.FINDCOLORPARMS then
					page[2] = basep.rect;
					page[3] = basep.colors;
				end
				if page.tap~=nil then
				local taps =	mult:get(page[1]..'tap')
				page.tap = {taps.x,taps.y}
				
				end
			
			else
				local basetap =	mult:get(page[1])
				page.tap = {basetap.x,basetap.y}
				
			end
		end
		
	end
	
	
end

function freegame.获取当前游戏界面()
	local result = "未知界面";
	local isGetUi = true;
	while isGetUi do
		log("获取当前游戏界面()-->循环")
		for k,v in pairs(pageList) do
			x,y = freegame.config.比色回调方法(v.f);
			if x>-1 or y>-1 then
				result =v.f[1];
				isGetUi = false;
				return v ;
			end
		end
		
		log("获取当前游戏界面()-->"..result)
		if result =="未知界面" then
			
			
		end
	end
	return nil;
end

function freegame.点击(x,y)
	local id;
	if freegame.config.点击痕迹~=nil and freegame.config.点击痕迹[1]  then
		id = createHUD()     --创建一个HUD
		showHUD(id,"",12,"0xffff0000",freegame.config.点击痕迹[2],0,x-20,y-20,40,40)
	end
	touchDown(1, random(x,5), random(y,5))
	mSleep(random(100,20))
	touchMove(1, random(x,5), random(y,5))
	mSleep(random(60,50))
	touchUp(1, random(x,5), random(y,5))
	log('点击')
	
	if freegame.config.点击痕迹~=nil  and freegame.config.点击痕迹[1] then
		showHUD(id,"",12,"0xffff0000",freegame.config.点击痕迹[2],0,x-25,y-25,50,50)
		mSleep(100);
		showHUD(id,"",12,"0xffff0000",freegame.config.点击痕迹[2],0,x-30,y-30,60,60)
		mSleep(300)
		hideHUD(id)
		--隐藏HUD
	end
	
end

--滑动函数（勾股原理）
--x1，y1 起始滑动坐标
--x2,y2 结束滑动坐标
--jd 每次滑动的距离，一般写5
--摘自 Zqys
function freegame.滑动(X1,Y1,X2,Y2,jD)
	local d = math.floor((((X2-X1)^2+(Y2-Y1)^2)^(1/2))/jD)
	local x,y= (X2-X1)/d,(Y2-Y1)/d
	touchDown(1, X1, Y1)
	for i = 1 ,d do
		touchMove(1, X1+x*i, Y1+y*i)
	end
	touchUp(1, X2, Y2)
end

-- 摘自 it疯子
-- 原理 随机捕捉屏幕上100个点的 颜色值缓存，下次获取判断颜色相似度
-- 使用该方法的同学注意,如果界面上人物没动，但是界面上有特效闪动
-- 【该方法返回1-100数值一般返回值>70，则视为屏幕静止】 可根据实际开发状态下判断大小值
function freegame.屏幕检测静止()
	local gc
	local js=0
	local ww,hh
	local w, h= getScreenSize() --获取设备分辨率
	if w>h then ww=w hh=h else ww=h hh=w end
	if oc==nil then
		oc={ --检测屏幕是否静止
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
		}
		
	end
	keepScreen(true)
	setScreenScale(w,h,0)
	for i=1,10 do
		for j=1,10 do
			-- ss=ss+1
			gc=getColor(i*math.ceil(ww/11),j*math.ceil(hh/11))
			if oc[i][j]==gc then
				js=js+1
			end
			oc[i][j]=gc
		end
	end
	keepScreen(false)
	sysLog('屏幕数量：'..js)
	return js
end

return freegame;