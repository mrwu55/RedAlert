require 'lib'
require 'CheckFree'
--采集 c--最大队列数
function outSideGetRes(c)
	local freeNum = freeTest(c);
	sysLog("空闲队列数-->"..freeNum);
	if freeNum ==0 then
		return;
	end
	
end
