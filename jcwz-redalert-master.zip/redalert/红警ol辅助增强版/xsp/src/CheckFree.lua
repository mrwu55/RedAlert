require("lib")
function freeTest(a)
	goOrBack(false);
	sleep(1000)
	clickWithColor(outSideGetres[1])
	sleep(1000)
	return freeTestLoop(a)--空闲队列
end
function freeTestLoop(a)
	
	if getPoints(outSideGetres[2])==false then--所有队列空闲
		return a
	else--至少一个队列任务中
		if getPoints(outSideGetres[3])==false then --B队列检测
			
			return a-1
		else
			if getPoints(outSideGetres[4])==false then --C队列检测
				return a-2
			else
				if getPoints(outSideGetres[5])==false then --D队列检测
					return a-3
				else
					if getPoints(outSideGetres[6])==false then --E队列检测
						return a-4
					else
						return 0
					end--E队列检测
				end--D队列检测
				
				
			end--C队列检测
		end--B队列检测
		
	end--所有队列空闲
	
	
	return 0
	
end

